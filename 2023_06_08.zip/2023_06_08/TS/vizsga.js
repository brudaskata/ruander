function EkezetesBetukSzama(vizsgaltSzoveg) {
    var ekezetesBetuk = ["á", "Á", "é", "É", "í", "Í", "ó", "Ó", "ö", "Ö", "ő", "Ő", "ú", "Ú", "ü", "Ü", "ű", "Ű"];
    var ekezetesBetukSzama = 0;
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        if (ekezetesBetuk.includes(vizsgaltSzoveg[i])) {
            ekezetesBetukSzama++;
        }
    }
    return ekezetesBetukSzama;
}
function ElsoNszamSzorzat(mennyiseg) {
    var szorzat = 1;
    for (var i = 1; i <= mennyiseg; i++) {
        szorzat = szorzat * i;
    }
    return szorzat;
}
function ParosakOsszege(vizsgaltTomb) {
    var osszeg = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            osszeg += vizsgaltTomb[i];
        }
    }
    return osszeg;
}
