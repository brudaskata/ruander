import { Component } from '@angular/core';

@Component({
  selector: 'app-feladat',
  templateUrl: './feladat.component.html',
  styleUrls: ['./feladat.component.css']
})

export class FeladatComponent {
  constructor() { }

  ngOnInit(): void { }

  vizsgaltszam!: number;
  eredmenyek: string[] = [];

  EredmenyMentes(): void {
    let oszto: number = 0;
    for (let i: number = 1; i <= this.vizsgaltszam; i++) {
      if (this.vizsgaltszam % i == 0) {
        oszto++;
      }
    }
    if (oszto == 2) {
      this.eredmenyek.push(`A ${this.vizsgaltszam}: prím`);
    } else {
      this.eredmenyek.push(`A ${this.vizsgaltszam}: NEM prím`);
    }
  }
}

