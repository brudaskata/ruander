import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EuComponent } from './eu/eu.component';
import { FifaComponent } from './fifa/fifa.component';
import { HelsinkiComponent } from './helsinki/helsinki.component';
import { SnookerComponent } from './snooker/snooker.component';
import { F1Component } from './f1/f1.component';
import { HibaComponent } from './hiba/hiba.component';

@NgModule({
  declarations: [
    AppComponent,
    EuComponent,
    FifaComponent,
    HelsinkiComponent,
    SnookerComponent,
    F1Component,
    HibaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
