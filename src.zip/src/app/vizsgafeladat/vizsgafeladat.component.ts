import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  constructor() { }

  ngOnInit(): void { }

  testsuly!: number;
  testmagassag!: number;
  testtomegIndex!: number;
  eredmenyek: string[] = [];


  EredmenyMentes(): void {
    if (this.testsuly && this.testmagassag) {
      this.testtomegIndex = this.testsuly / (this.testmagassag * this.testmagassag);
      const eredmeny = `Magasság: ${this.testmagassag}, Súly: ${this.testsuly}, Testtömeg index: ${this.testtomegIndex.toFixed(2)}`;
      this.eredmenyek.push(eredmeny);
    }
  }
}