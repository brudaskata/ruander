
function EkezetesBetukSzama(modositandoSzoveg) {
    var ekezetesBetuk = ['á', 'é', 'í', 'ó', 'ö', 'ő', 'ú', 'ü', 'ű'];
    var ekezetesBetukSzama = 0;
    for (var i = 0; i < modositandoSzoveg.length; i++) {
        if (ekezetesBetuk.includes(modositandoSzoveg[i].toLowerCase())) {
            ekezetesBetukSzama++;
        }
    }
    return ekezetesBetukSzama;
}
function PrimLista(vizsgaltTomb) {
    var primSzamok = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var oszto = 0;
        for (var j = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        if (oszto === 2) {
            primSzamok.push(vizsgaltTomb[i]);
        }
    }
    if (primSzamok.length > 0) {
        return primSzamok;
    }
    else {
        return "Nincs prímszám a tömbben";
    }
}
var eredmeny = EkezetesBetukSzama("Ez a kód jól működik.");
console.log("A szövegben található ékezetes betűk száma:" + eredmeny);
var eredmeny2 = PrimLista([4, 10, 20]);
console.log(eredmeny2);
var eredmeny3 = PrimLista([3, 7, 20]);
console.log(eredmeny3);
