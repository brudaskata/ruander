export { }
function EkezetesBetukSzama(modositandoSzoveg: string): number {
    let ekezetesBetuk: string[] = ['á', 'é', 'í', 'ó', 'ö', 'ő', 'ú', 'ü', 'ű'];
    let ekezetesBetukSzama: number = 0;
    for (let i: number = 0; i < modositandoSzoveg.length; i++) {
        if (ekezetesBetuk.includes(modositandoSzoveg[i].toLowerCase())) {
            ekezetesBetukSzama++;
        }
    }
    return ekezetesBetukSzama;

}






function PrimLista(vizsgaltTomb: number[]): any {
    let primSzamok: number[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let oszto: number = 0;
        for (let j: number = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        if (oszto === 2) {
            primSzamok.push(vizsgaltTomb[i]);
        }
    }

    if (primSzamok.length > 0) {
        return primSzamok;
    }

    else {
        return "Nincs prímszám a tömbben";
    }
}

let eredmeny: number = EkezetesBetukSzama("Ez a kód jól működik.");
console.log("A szövegben található ékezetes betűk száma:" + eredmeny);

let eredmeny2: string = PrimLista([4, 10, 20]);
console.log(eredmeny2);

let eredmeny3: number[] = PrimLista([3, 7, 20]);
console.log(eredmeny3);

