function FuggvenyVisszajelzoSor(tesztNeve, adatBe, elvartEredmeny, fuggvenyhivas) {


    var table = document.querySelector("#testTable");
    var adatSor = table.insertRow(table.rows.length);
    var tesztNeveMezo = adatSor.insertCell(0);
    var bemenetMezo = adatSor.insertCell(1);
    var elvartEredmenyMezo = adatSor.insertCell(2);
    var fuggvenyEredmenyMezo = adatSor.insertCell(3)
    var visszajelzesMezo = adatSor.insertCell(4)


    tesztNeveMezo.innerHTML = `${tesztNeve}`;
    bemenetMezo.innerHTML = `${adatBe}`;
    elvartEredmenyMezo.innerHTML = `${elvartEredmeny}`;
    fuggvenyEredmenyMezo.innerHTML = `${fuggvenyhivas}`
    if (elvartEredmeny == fuggvenyhivas) {
        visszajelzesMezo.innerHTML = `Success`;
    }
    else {
        visszajelzesMezo.innerHTML = `Fail`;
    }
}

function HibasFuggvenyFuggvenyVisszajelzoSor(tesztNeve, adatBe, elvartEredmeny) {
    var table = document.querySelector("#testTable");
    var adatSor = table.insertRow(table.rows.length);
    var tesztNeveMezo = adatSor.insertCell(0);
    var bemenetMezo = adatSor.insertCell(1);
    var elvartEredmenyMezo = adatSor.insertCell(2);
    var fuggvenyEredmenyMezo = adatSor.insertCell(3)
    var visszajelzesMezo = adatSor.insertCell(4)

    tesztNeveMezo.innerHTML = `${tesztNeve}`;
    bemenetMezo.innerHTML = `${adatBe}`;
    elvartEredmenyMezo.innerHTML = `${elvartEredmeny}`;
    fuggvenyEredmenyMezo.innerHTML = "Fail";
    visszajelzesMezo.innerHTML = "Fail";
}


function TesztEkezetesBetukSzama() {
    try {
        FuggvenyVisszajelzoSor("Ékezetes betűk száma", "Ez a kód jól működik.", 4, EkezetesBetukSzama("Ez a kód jól működik."));
    }
    catch {
        HibasFuggvenyFuggvenyVisszajelzoSor("Ékezetes betűk száma", "Ez a kód jól működik.", 4);
    }
}

function TesztPrimLista() {
    try {
        FuggvenyVisszajelzoSor("Van-e benne prím", [4, 10, 20], "Nincs prímszám a tömbben", PrimLista([4, 10, 20]));
    }
    catch {
        HibasFuggvenyFuggvenyVisszajelzoSor("Van-e benne prím", [4, 10, 20], "Nincs prímszám a tömbben");
    }
}

function TesztPrimLista2() {
    try {
        FuggvenyVisszajelzoSor("Van-e benne prím", [3, 7, 20], [3, 7], PrimLista([3, 7, 20]));
    }
    catch {
        HibasFuggvenyFuggvenyVisszajelzoSor("Van-e benne prím", [3, 7, 20], [3, 7]);
    }
}


function TesztFuttato() {
    TesztEkezetesBetukSzama();
    TesztPrimLista();
    TesztPrimLista2();

}
TesztFuttato();
