import { Component } from '@angular/core';

@Component({
  selector: 'app-hiba',
  templateUrl: './hiba.component.html',
  styleUrls: ['./hiba.component.css']
})
export class HibaComponent {

}
