import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrls: ['./hosegriado.component.css']
})
export class HosegriadoComponent {

  kozephomerseklet1!: number;
  kozephomerseklet2!: number;
  kozephomerseklet3!: number;

  aktualisRiadoSzint(): string {
    if (this.kozephomerseklet1 && this.kozephomerseklet2 && this.kozephomerseklet3) {
      if (this.kozephomerseklet1 >= 27 && this.kozephomerseklet2 >= 27 && this.kozephomerseklet3 >= 27) {
        return "3.szintű";
      }
      if (this.kozephomerseklet1 >= 25 && this.kozephomerseklet2 >= 25 && this.kozephomerseklet3 >= 25) {
        return "2.szintű";
      }
      if (this.kozephomerseklet1 >= 25 || this.kozephomerseklet2 >= 25 || this.kozephomerseklet3 >= 25) {
        return "1.szintű";
      }
      if (this.kozephomerseklet1 < 25 && this.kozephomerseklet2 < 25 && this.kozephomerseklet3 < 25) {
        return "0. szintű";
      }
    }
    return "Nincs adat!";
  }

  eredmeny: string = this.aktualisRiadoSzint();

  EredmenyMentese(): void {
    if (this.kozephomerseklet1 && this.kozephomerseklet2 && this.kozephomerseklet3) {
      const kiiras = `${this.kozephomerseklet1}, ${this.kozephomerseklet2} és ${this.kozephomerseklet3} esetén ${this.aktualisRiadoSzint()} hőségriadó volt elrendelve`;
      this.statisztika.push(kiiras);

    }
  }
  statisztika: string[] = [];
}
