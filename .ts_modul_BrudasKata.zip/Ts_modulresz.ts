export { }
function PhErtek(vizsgaltErtek: number): string {
    let allapot: string = "";
    if (vizsgaltErtek == 7) {
        allapot = "semleges";
    }
    else if (vizsgaltErtek > 7) {
        allapot = "lugos";
    }
    else {
        allapot = "savas";
    }
    return allapot;
}

function PrimekSzama(vizsgaltTomb: number[]): number {
    let osztokszama: number[] = [];
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let oszto: number = 0;
        for (let j: number = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        osztokszama.push(oszto);
    }

    let primekszama = 0;
    for (let i: number = 0; i < osztokszama.length; i++) {
        if (osztokszama[i] === 2) {
            primekszama++;
        }
    }
    return primekszama;
}

function MaganHangzokSzama(vizsgaltSzoveg: string): number {
    let maganhangzok: string[] = ['a', 'á', 'e', 'é', 'i', 'í', 'o', 'ó', 'ö', 'ő', 'u', 'ú', 'ü', 'ű'];
    let maganhangzokSzama: number = 0;
    for (let i: number = 0; i < vizsgaltSzoveg.length; i++) {
        if (maganhangzok.includes(vizsgaltSzoveg[i].toLowerCase())) {
            maganhangzokSzama++;
        }
    }
    return maganhangzokSzama;
}
