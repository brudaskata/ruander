
function PhErtek(vizsgaltErtek) {
    var allapot = "";
    if (vizsgaltErtek == 7) {
        allapot = "semleges";
    }
    else if (vizsgaltErtek > 7) {
        allapot = "lugos";
    }
    else {
        allapot = "savas";
    }
    return allapot;
}
function PrimekSzama(vizsgaltTomb) {
    var osztokszama = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var oszto = 0;
        for (var j = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        osztokszama.push(oszto);
    }
    var primekszama = 0;
    for (var i = 0; i < osztokszama.length; i++) {
        if (osztokszama[i] === 2) {
            primekszama++;
        }
    }
    return primekszama;
}
function MaganHangzokSzama(vizsgaltSzoveg) {
    var maganhangzok = ['a', 'á', 'e', 'é', 'i', 'í', 'o', 'ó', 'ö', 'ő', 'u', 'ú', 'ü', 'ű'];
    var maganhangzokSzama = 0;
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        if (maganhangzok.includes(vizsgaltSzoveg[i].toLowerCase())) {
            maganhangzokSzama++;
        }
    }
    return maganhangzokSzama;
}
