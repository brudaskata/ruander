function ujVisszajelzoSor(tesztneve, visszajelzes) {
    var table = document.querySelector("#testTable");
    var adatSor = table.insertRow(1);
    var tesztNeveMezo = adatSor.insertCell(0);
    var visszajelzesMezo = adatSor.insertCell(1);
    tesztNeveMezo.innerHTML = `${tesztneve}`;
    visszajelzesMezo.innerHTML = `${visszajelzes}`;
}

function teszt01() {
    try {
        let tesztElem = document.querySelector("div");
        if (tesztElem.classList == "container") {
            ujVisszajelzoSor("Külső div elem azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Külső div elem azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Külső div elem azonosítója", "HIBA");
    }
}

function teszt02() {
    try {
        let tesztElem = document.querySelector("h1");
        if (tesztElem.innerHTML == "Tanfolyam regisztráció") {
            ujVisszajelzoSor("1-es szintű címsor tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("1-es szintű címsor tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("1-es szintű címsor tartalma", "HIBA");
    }
}

function teszt03() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[0].type == "text") {
            ujVisszajelzoSor("Első input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Első input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Első input mező típusa", "HIBA");
    }
}

function teszt04() {
    try {
        let tesztElem = document.querySelector("#veznev");
        if (tesztElem.id = "veznev") {
            ujVisszajelzoSor("Első input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Első input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Első input mező azonosítója", "HIBA");
    }
}

function teszt05() {
    try {
        let tesztElem = document.querySelectorAll("#veznev");
        if (tesztElem.classList = "form-control") {
            ujVisszajelzoSor("Első input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Első input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Első input mező bootstrap osztálya", "HIBA");
    }
}

function teszt06() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[1].type == "text") {
            ujVisszajelzoSor("Második input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Második input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Második input mező típusa", "HIBA");
    }
}

function teszt07() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[1].id == "kernev") {
            ujVisszajelzoSor("Második input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Második input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Második input mező azonosítója", "HIBA");
    }
}

function teszt08() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[1].classList == "form-control") {
            ujVisszajelzoSor("Második input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Második input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Második input mező bootstrap osztálya", "HIBA");
    }
}

function teszt09() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[2].type == "text") {
            ujVisszajelzoSor("Harmadik input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Harmadik input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Harmadik input mező típusa", "HIBA");
    }
}

function teszt10() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[2].id == "fnev") {
            ujVisszajelzoSor("Harmadik input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Harmadik input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Harmadik input mező azonosítója", "HIBA");
    }
}

function teszt11() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[2].classList == "form-control") {
            ujVisszajelzoSor("Harmadik input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Harmadik input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Harmadik input mező bootstrap osztálya", "HIBA");
    }
}

function teszt12() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[3].type == "password") {
            ujVisszajelzoSor("Negyedik input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Negyedik input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Negyedik input mező típusa", "HIBA");
    }
}

function teszt13() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[3].id == "pass1") {
            ujVisszajelzoSor("Negyedik input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Negyedik input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Negyedik input mező azonosítója", "HIBA");
    }
}

function teszt14() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[3].classList == "form-control") {
            ujVisszajelzoSor("Negyedik input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Negyedik input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Negyedik input mező bootstrap osztálya", "HIBA");
    }
}

function teszt15() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[4].type == "password") {
            ujVisszajelzoSor("Ötödik input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Ötödik input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Ötödik input mező típusa", "HIBA");
    }
}

function teszt16() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[4].id == "pass2") {
            ujVisszajelzoSor("Ötödik input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Ötödik input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Ötödik input mező azonosítója", "HIBA");
    }
}

function teszt17() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[4].classList.contains("form-control")) {
            ujVisszajelzoSor("Ötödik input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Ötödik input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Ötödik input mező bootstrap osztálya", "HIBA");
    }
}

function teszt18() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[5].id == "email") {
            ujVisszajelzoSor("Hatodik input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Hatodik input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Hatodik input mező azonosítója", "HIBA");
    }
}

function teszt19() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[5].type == "email") {
            ujVisszajelzoSor("Hatodik input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Hatoik input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Hatodik input mező típusa", "HIBA");
    }
}

function teszt20() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[5].classList.contains("form-control")) {
            ujVisszajelzoSor("Hatodik input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Hatodik input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Hatodik input mező bootstrap osztálya", "HIBA");
    }
}

function teszt21() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[6].type == "text") {
            ujVisszajelzoSor("Hetedik input mező típusa", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Hetedik input mező típusa", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Hetedik input mező típusa", "HIBA");
    }
}

function teszt22() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[6].id == "tel") {
            ujVisszajelzoSor("Hetedik input mező azonosítója", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Hetedik input mező azonosítója", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Hetedik input mező azonosítója", "HIBA");
    }
}

function teszt23() {
    try {
        let tesztElem = document.querySelectorAll("input");
        if (tesztElem[6].classList.contains("form-control")) {
            ujVisszajelzoSor("Hetedik input mező bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Hetedik input mező bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Hetedik input mező bootstrap osztálya", "HIBA");
    }
}

function teszt24() {
    let tesztElem = document.querySelectorAll(".form-group");
    let mindTartalmazza = false;
    for (let i = 0; i < tesztElem.length; i++) {
        let inputMezo = tesztElem[i].querySelector(":nth-child(2)");
        if (inputMezo.classList.contains("form-control")) {
            mindTartalmazza = true;
        }
    }
    if (mindTartalmazza === true) {
        ujVisszajelzoSor("Összes mező form-control osztálya", "Megfelelő");
    }
    else {
        ujVisszajelzoSor("Összes mező form-control osztálya", "NEM megfelelő");
    }
}

function teszt25() {
    try {
        let tesztElem = document.querySelector("label[for='veznev']");
        if (tesztElem.innerHTML == "Vezeték név:") {
            ujVisszajelzoSor("1. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("1. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("1. label tartalma", "HIBA");
    }
}

function teszt26() {
    try {
        let tesztElem = document.querySelector("label[for='kernev']");
        if (tesztElem.innerHTML == "Kereszt név:") {
            ujVisszajelzoSor("2. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("2. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("2. label tartalma", "HIBA");
    }
}

function teszt27() {
    try {
        let tesztElem = document.querySelector("label[for='fnev']");
        if (tesztElem.innerHTML == "Felhasználói név:") {
            ujVisszajelzoSor("3. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("3. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("3. label tartalma", "HIBA");
    }
}

function teszt28() {
    try {
        let tesztElem = document.querySelector("label[for='pass1']");
        if (tesztElem.innerHTML == "Jelszó:") {
            ujVisszajelzoSor("4. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("4. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("4. label tartalma", "HIBA");
    }
}

function teszt29() {
    try {
        let tesztElem = document.querySelector("label[for='pass2']");
        if (tesztElem.innerHTML == "Jelszó ismét:") {
            ujVisszajelzoSor("5. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("5. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("5. label tartalma", "HIBA");
    }
}

function teszt30() {
    try {
        let tesztElem = document.querySelector("label[for='email']");
        if (tesztElem.innerHTML == "E-mail cím:") {
            ujVisszajelzoSor("6. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("6. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("6. label tartalma", "HIBA");
    }
}

function teszt31() {
    try {
        let tesztElem = document.querySelector("label[for='tel']");
        if (tesztElem.innerHTML == "Telefonszám:") {
            ujVisszajelzoSor("7. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("7. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("7. label tartalma", "HIBA");
    }
}

function teszt32() {
    try {
        let tesztElem = document.querySelector("label[for='tipus']");
        if (tesztElem.innerHTML == "Tanfolyam típusa:") {
            ujVisszajelzoSor("8. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("8. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("8. label tartalma", "HIBA");
    }
}

function teszt33() {
    try {
        let tesztElem = document.querySelector("label[for='box']");
        if (tesztElem.innerHTML == "Adatvédelmi nyilatkozat elfogadása") {
            ujVisszajelzoSor("9. label tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("9. label tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("9. label tartalma", "HIBA");
    }
}

function teszt34() {
    try {
        let tesztElem = document.querySelector("#fnev+small");
        if (tesztElem.innerHTML == "Beceneve, mely mások számára is látható.") {
            ujVisszajelzoSor("Felhasználói név mező alatti üzenet tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Felhasználói név mező alatti üzenet tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Felhasználói név mező alatti üzenet tartalma", "HIBA");
    }
}

function teszt35() {
    try {
        let tesztElem = document.querySelector("#email+small");
        if (tesztElem.innerHTML == "Ide továbbítjuk a legfontosabb tanfolyam információkat önnek.") {
            ujVisszajelzoSor("E-mail cím mező alatti üzenet tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("E-mail cím mező alatti üzenet tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("E-mail cím mező alatti üzenet tartalma", "HIBA");
    }
}

function teszt36() {
    try {
        let tesztElem = document.querySelector("#tel+small");
        if (tesztElem.innerHTML == "Ha szeretne akár azonnal értesülni a fontosabb hírekről.") {
            ujVisszajelzoSor("Telefonszám mező alatti üzenet tartalma", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Telefonszám mező alatti üzenet tartalma", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Felhasználói név mező alatti üzenet tartalma", "HIBA");
    }
}

function teszt37() {
    let tesztElem = document.querySelectorAll("small");
    let mindTartalmazza2 = false;
    for (let i = 0; i < tesztElem.length; i++) {
        if (tesztElem[i].classList.contains("form-text", "text-muted")) {
            mindTartalmazza2 = true;
        }
    }
    if (mindTartalmazza2 === true) {
        ujVisszajelzoSor("Small mezőkhöz tartozó osztályok", "Megfelelő");
    }
    else {
        ujVisszajelzoSor("Small mezőkhöz tartozó osztályok", "NEM megfelelő");
    }
}

function teszt38() {
    try {
        let tesztElem = document.querySelector("button");
        if (tesztElem.classList.contains("btn")) {
            ujVisszajelzoSor("A gomb alapértelmezett bootstrap osztálya", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("A gomb alapértelmezett bootstrap osztálya", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("A gomb alapértelmezett bootstrap osztálya", "HIBA");
    }
}

function teszt39() {
    try {
        let tesztElem = document.querySelector("button");
        if (tesztElem.classList.contains("btn-primary")) {
            ujVisszajelzoSor("A gomb színe", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("A gomb színe", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("A gomb színe", "HIBA");
    }
}

function teszt40() {
    try {
        let tesztElem = document.querySelector("button");
        if (tesztElem.classList.contains("form-control")) {
            ujVisszajelzoSor("Gomb méretének módosításan", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Gomb méretének módosítása", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Gomb méretének módosítása", "HIBA");
    }
}

function teszt41() {
    try {
        let tesztElem = document.querySelector("button");
        if (tesztElem.innerHTML == "Regisztrálok") {
            ujVisszajelzoSor("Gomb felirata", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Gomb felirata", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Gomb felirata", "HIBA");
    }
}

function teszt42() {
    let tesztElem = document.querySelectorAll("#tipus");
    let elemekSzama = tesztElem.length;
    for (let i = 0; i < tesztElem.length; i++) {
        return elemekSzama;
    }
    if (elemekSzama === 4) {
        ujVisszajelzoSor("Select mezőben lévő elemek száma", "Megfelelő");
    }
    else {
        ujVisszajelzoSor("Select mezőben lévő elemek száma", "NEM megfelelő");
    }
}


function teszt43() {
    try {
        let tesztElem = document.querySelector("#tipus option[selected]");
        if (tesztElem.innerHTML == "Webfejlesztő") {
            ujVisszajelzoSor("Select mezőben kiválasztott elem értéke", "Megfelelő");
        }
        else {
            ujVisszajelzoSor("Select mezőben kiválasztott elem értéke", "NEM megfelelő");
        }
    }
    catch {
        ujVisszajelzoSor("Select mezőben kiválasztott elem értéke", "HIBA");
    }
}




function allTeszt() {
    teszt01();
    teszt02();
    teszt03();
    teszt04();
    teszt05();
    teszt06();
    teszt07();
    teszt08();
    teszt09();
    teszt10();
    teszt11();
    teszt12();
    teszt13();
    teszt14();
    teszt15();
    teszt16();
    teszt17();
    teszt18();
    teszt19();
    teszt20();
    teszt21();
    teszt22();
    teszt23();
    teszt24();
    teszt25();
    teszt26();
    teszt27();
    teszt28();
    teszt29();
    teszt30();
    teszt31();
    teszt32();
    teszt33();
    teszt34();
    teszt35();
    teszt36();
    teszt37();
    teszt38();
    teszt39();
    teszt40();
    teszt41();
    teszt42();
    teszt43();
}
allTeszt();