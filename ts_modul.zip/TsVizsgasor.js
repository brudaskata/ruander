
function Rng(alsoHatar, felsoHatar) {
    var randomSzam = 0;
    return randomSzam = Math.round(Math.random() * (felsoHatar - alsoHatar) + alsoHatar);
}
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var randomTomb = [];
    for (var i = 0; i < meret; i++) {
        randomTomb.push(Rng(alsoHatar, felsoHatar));
    }
    return randomTomb;
}
function Duplazo(eredmeny2) {
    var szamDuplazva = 0;
    var tombDuplazva = [];
    for (var i = 0; i < eredmeny2.length; i++) {
        szamDuplazva = eredmeny2[i] * 2;
        tombDuplazva.push(szamDuplazva);
    }
    return tombDuplazva;
}
function PrimekSzama(eredmeny2) {
    var osztokszama = [];
    for (var i = 0; i < eredmeny2.length; i++) {
        var oszto = 0;
        for (var j = 1; j <= eredmeny2[i]; j++) {
            if (eredmeny2[i] % j === 0) {
                oszto++;
            }
        }
        osztokszama.push(oszto);
    }
    var primekszama = 0;
    for (var i = 0; i < osztokszama.length; i++) {
        if (osztokszama[i] === 2) {
            primekszama++;
        }
    }
    return primekszama;
}
function EgyediElemek(eredmeny2) {
    var egyedielemek = [];
    for (var i = 0; i < eredmeny2.length; i++) {
        var szerepelE = false;
        for (var j = 0; j < egyedielemek.length; j++) {
            if (egyedielemek[j] === eredmeny2[i]) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            egyedielemek.push(eredmeny2[i]);
        }
    }
    return egyedielemek;
}
var eredmeny = Rng(1, 100);
console.log("A generált random szám: " + eredmeny);
var eredmeny2 = TombGenerator(10, 1, 100);
console.log("A generált tömb:" + eredmeny2);
var eredmeny3 = Duplazo(eredmeny2);
console.log("A duplázott tömb elemei:" + eredmeny3);
var eredmeny4 = PrimekSzama(eredmeny2);
console.log("A generált tömbben található prímszámok száma:" + eredmeny4);
var eredmeny5 = EgyediElemek(eredmeny2);
console.log("A generált tömbben található egyedi elemek:" + eredmeny5);
