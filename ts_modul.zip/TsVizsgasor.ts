export { }
function Rng(alsoHatar: number, felsoHatar: number): number {
    let randomSzam: number = 0;
    return randomSzam = Math.round(Math.random() * (felsoHatar - alsoHatar) + alsoHatar);
}

function TombGenerator(meret: number, alsoHatar: number, felsoHatar: number): number[] {
    let randomTomb: number[] = [];
    for (let i: number = 0; i < meret; i++) {
        randomTomb.push(Rng(alsoHatar, felsoHatar));
    }
    return randomTomb;
}


function Duplazo(eredmeny2: number[]): number[] {
    let szamDuplazva: number = 0;
    let tombDuplazva: number[] = [];
    for (let i: number = 0; i < eredmeny2.length; i++) {
        szamDuplazva = eredmeny2[i] * 2;
        tombDuplazva.push(szamDuplazva);
    }
    return tombDuplazva;
}

function PrimekSzama(eredmeny2: number[]): number {
    let osztokszama: number[] = [];
    for (let i: number = 0; i < eredmeny2.length; i++) {
        let oszto: number = 0;
        for (let j = 1; j <= eredmeny2[i]; j++) {
            if (eredmeny2[i] % j === 0) {
                oszto++;
            }
        }
        osztokszama.push(oszto);
    }

    let primekszama = 0;
    for (let i = 0; i < osztokszama.length; i++) {
        if (osztokszama[i] === 2) {
            primekszama++;
        }
    }
    return primekszama;
}

function EgyediElemek(eredmeny2: number[]): number[] {
    let egyedielemek: number[] = [];
    for (let i: number = 0; i < eredmeny2.length; i++) {
        let szerepelE: boolean = false;
        for (let j: number = 0; j < egyedielemek.length; j++) {
            if (egyedielemek[j] === eredmeny2[i]) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            egyedielemek.push(eredmeny2[i]);
        }
    }
    return egyedielemek;
}

let eredmeny: number = Rng(1, 100);
console.log("A generált random szám: " + eredmeny);

let eredmeny2: number[] = TombGenerator(10, 1, 100);
console.log("A generált tömb:" + eredmeny2);

let eredmeny3: number[] = Duplazo(eredmeny2);
console.log("A duplázott tömb elemei:" + eredmeny3);

let eredmeny4: number = PrimekSzama(eredmeny2);
console.log("A generált tömbben található prímszámok száma:" + eredmeny4);

let eredmeny5: number[] = EgyediElemek(eredmeny2);
console.log("A generált tömbben található egyedi elemek:" + eredmeny5);

