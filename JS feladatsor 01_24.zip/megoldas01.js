<script>
//function keszito();

function keszito(){
document.write ("Brudás Katalin<br>");
document.write ("Junior frontend<br>");
document.write ("Team#11<br>");
}

keszito();



</script>
