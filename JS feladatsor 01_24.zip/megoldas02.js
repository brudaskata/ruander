<script>
//function hatvanyozo();
function hatvanyozo(szam, hatvany){

let hatvanyozo=Math.pow(szam,hatvany);

document.write ("<hr>");
document.write (`A(z) ${szam} ${hatvany}-ik hatványa: ${hatvanyozo}`);
}

hatvanyozo (2,3);
hatvanyozo (5,3);

</script>