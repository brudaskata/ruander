<script>
//function testTomegIndex();
function testTomegIndex (suly, magassag){
let TTI=suly/magassag**2; 

if(TTI<16){
	document.write(`${TTI} esetén, súlyos soványság`);
}
else if(TTI<17){
	document.write(`${TTI} esetén, mérsékelt soványság`);
}
else if(TTI<18.5){
	document.write(`${TTI} esetén, enyhe soványság`);
}
else if(TTI<25){
	document.write(`${TTI} esetén, normális testsúly`);
}
else if(TTI<30){
	document.write(`${TTI} esetén, túlsúlyos`);
}
else if(TTI<35){
	document.write(`${TTI} esetén, I. fokú elhízás`);
}
else if(TTI<40){
	document.write(`${TTI} esetén, II. fokú elhízás`);
}
else{
	document.write(`${TTI} esetén, III. fokú (súlyos) elhízás`);
}
}

testTomegIndex(200,2);
document.write ("<hr>");
testTomegIndex(45,1.5);
document.write ("<hr>");
testTomegIndex(25,1.2);

</script>
