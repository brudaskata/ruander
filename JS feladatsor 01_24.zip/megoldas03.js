<script>
//function parosLetrehoz();
function parosLetrehoz(){
let generaltSzam=Math.round(Math.random()*100);

if (generaltSzam%2==0){
document.write (`${generaltSzam}`);
}

else {}
}

parosLetrehoz(1,100);
</script>