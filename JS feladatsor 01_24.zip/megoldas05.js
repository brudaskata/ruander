<script>
//function egeszOsztoE();
function egeszOsztoE (szam, oszto){

if(szam%oszto==0){
document.write(`true`);
}
else{
document.write(`false`);
}
}

egeszOsztoE(25,5);
document.write ("<hr>");
egeszOsztoE(1050,7);
document.write ("<hr>");
egeszOsztoE(2048,3);
document.write ("<hr>");
</script>
