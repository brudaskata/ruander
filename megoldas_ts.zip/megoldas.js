
function DiakInfo(nev, csoport, tipus) {
    var elotag = "Team0" + csoport;
    var vegzettseg = tipus ? "Junior Frontend" : "Webprogramozó";
    return "".concat(nev, " ").concat(elotag, " ").concat(vegzettseg);
}
var eredmeny = DiakInfo("Minta Márton", 8, true);
console.log(eredmeny);
function SzovegesErtekeles(jegy) {
    if (jegy === 5) {
        return ["Példás", "Példás"];
    }
    else if (jegy === 4) {
        return ["Jó", "Jó"];
    }
    else if (jegy === 3) {
        return ["Változó", "Változó"];
    }
    else if (jegy === 2) {
        return ["Hanyag", "Rossz"];
    }
    else {
        return ["Hibás adat!", ""];
    }
}
var ertekeles = SzovegesErtekeles(2);
console.log("Az értékelés eredménye:" + ertekeles);
function HarommalOszthatokSzama(vizsgaltTomb) {
    var harommalOszthatoak = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 3 === 0) {
            harommalOszthatoak++;
        }
    }
    return harommalOszthatoak;
}
var harommalOszthatoakSzama = HarommalOszthatokSzama([10, 23, 12, 24, 31, 33, 42, 20]);
console.log("A tömbben lévő hárommal osztható elemek száma: " + harommalOszthatoakSzama);
function Nyeroszamok(mennyiseg, alsoHatar, felsoHatar) {
    var NyeroSzamok = [];
    for (var i = 0; i < mennyiseg; i++) {
        var generaltSzam = Math.round(Math.random() * felsoHatar - alsoHatar + 1) + alsoHatar;
        var szerepelE = false;
        for (var j = 0; j < NyeroSzamok.length; j++) {
            if (generaltSzam == NyeroSzamok[j]) {
                szerepelE = true;
            }
        }
        if (szerepelE == false) {
            NyeroSzamok.push(generaltSzam);
        }
        else {
            i--;
        }
    }
    return NyeroSzamok;
}
var kihuzottSzamok = Nyeroszamok(5, 1, 90);
console.log("A kihúzott nyerőszámok:" + kihuzottSzamok);
