export { };
function DiakInfo(nev: string, csoport: number, tipus: boolean): string {
    let elotag: string = "Team0" + csoport;
    let vegzettseg: string = tipus ? "Junior Frontend" : "Webprogramozó";

    return `${nev} ${elotag} ${vegzettseg}`;
}

let eredmeny: string = DiakInfo("Minta Márton", 8, true);
console.log(eredmeny);

function SzovegesErtekeles(jegy: number): [string, string] {
    if (jegy === 5) {
        return ["Példás", "Példás"];
    }

    else if (jegy === 4) {
        return ["Jó", "Jó"];
    }

    else if (jegy === 3) {
        return ["Változó", "Változó"]
    }

    else if (jegy === 2) {
        return ["Hanyag", "Rossz"]
    }

    else {
        return ["Hibás adat!", ""]
    }
}

let ertekeles: [string, string] = SzovegesErtekeles(2);
console.log("Az értékelés eredménye:" + ertekeles);

function HarommalOszthatokSzama(vizsgaltTomb: number[]): number {
    let harommalOszthatoak: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 3 === 0) {
            harommalOszthatoak++;
        }
    }
    return harommalOszthatoak;
}

let harommalOszthatoakSzama: number = HarommalOszthatokSzama([10, 23, 12, 24, 31, 33, 42, 20]);
console.log("A tömbben lévő hárommal osztható elemek száma: " + harommalOszthatoakSzama);

function Nyeroszamok(mennyiseg: number, alsoHatar: number, felsoHatar: number): number[] {
    let NyeroSzamok: number[] = [];
    for (let i = 0; i < mennyiseg; i++) {
        let generaltSzam: number = Math.round(Math.random() * felsoHatar - alsoHatar + 1) + alsoHatar;
        let szerepelE: boolean = false;
        for (let j = 0; j < NyeroSzamok.length; j++) {
            if (generaltSzam == NyeroSzamok[j]) {
                szerepelE = true;
            }
        }

        if (szerepelE == false) {
            NyeroSzamok.push(generaltSzam);
        }
        else {
            i--;
        }
    }
    return NyeroSzamok;
}

let kihuzottSzamok: Number[] = Nyeroszamok(5, 1, 90);
console.log("A kihúzott nyerőszámok:" + kihuzottSzamok);




