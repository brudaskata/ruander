kibeaktivalo.addEventListener("click", CheckUnCheck);

function CheckUnCheck() {
    let elemLista = document.querySelectorAll(".allapot");
    for (let i = 0; i < elemLista.length; i++) {
        if (elemLista[i].checked === true) {
            elemLista[i].checked = false;
        } else {
            elemLista[i].checked = true;
        }
    }
}

csikozaskibe.addEventListener("click", KibeCsikozas);
function KibeCsikozas() {
    let tableObjektum = document.querySelector("table");
    if (tableObjektum.classList.contains("table-striped")) {
        tableObjektum.classList.remove("table-striped");
    }
    else {
        tableObjektum.classList.add("table-striped");
    }
}

darklightMode.addEventListener("click", DarkLightMode);
function DarkLightMode() {
    let tableObjektum = document.querySelector("table");
    if (tableObjektum.classList.contains("table-dark")) {
        tableObjektum.classList.remove("table-dark");
        tableObjektum.classList.add("table-light");
    }
    else {
        tableObjektum.classList.remove("table-light");
        tableObjektum.classList.add("table-dark");
    }
}



